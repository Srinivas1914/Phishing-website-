# Phishing Website Detection Mini Project

## Steps to Run:
1. Extract the zip file.
2. Make sure you have Python installed with sklearn & pandas.
   Install: pip install scikit-learn pandas
3. Run the project:
   python phishing_detection.py
4. Check accuracy, rules, and predictions.

Files:
- phishing.csv -> Dataset
- phishing_detection.py -> Python code
- project_report.txt -> Mini project report
- readme.txt -> Instructions
