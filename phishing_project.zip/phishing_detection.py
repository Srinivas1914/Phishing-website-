import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text

# Load dataset
df = pd.read_csv("phishing.csv")

X = df.drop("Label", axis=1)
y = df["Label"]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train Decision Tree model
clf = DecisionTreeClassifier()
clf.fit(X_train, y_train)

# Accuracy
print("Model Accuracy:", clf.score(X_test, y_test))

# Show rules
tree_rules = export_text(clf, feature_names=list(X.columns))
print(tree_rules)

# Test prediction
sample = [[1, 1, -1, 1, 1]]  # Example input
print("Prediction for sample:", clf.predict(sample))
